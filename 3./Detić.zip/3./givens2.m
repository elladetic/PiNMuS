function[c,s]=givens2(a,b) 
%primjer poziva funkcije [c,s] = givens2(4,5)
    if b == 0
    c = 1;
    s = 0;
    else
        if abs(b) > abs(a)
            r = a / b;
            s = 1 / sqrt(1 + r^2);
            c = s*r;
        else
            r = b / a;
            c = 1 / sqrt(1 + r^2);
            s = c*r;
        end
    end
end